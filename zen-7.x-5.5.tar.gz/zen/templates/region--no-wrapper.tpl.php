<?php
/**
 * @file
 * Returns the HTML for a region with bare minimum HTML.
 *
 * Complete documentation for this file is available online.
 * @see https://drupal.org/node/1728134
 */
?>

<?php print $content; ?>
