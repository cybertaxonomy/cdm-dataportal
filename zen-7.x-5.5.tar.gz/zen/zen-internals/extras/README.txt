ABOUT THIS DIRECTORY
--------------------

The contents of this folder are only used by the generate.sh command-line script
to help the maintainers keep the CSS and Sass files in sync. These files are not
used by Drupal, so feel free to ignore.
